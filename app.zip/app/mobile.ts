export interface IMobile
{
	mobId:number;
	mobName:string;
	mobPrice:number;
	
	
}