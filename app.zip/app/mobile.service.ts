import { Injectable } from '@angular/core';

import { IMobile } from './mobile';

@Injectable()
export class MobileService{
	
	getAllMobile():IMobile[]


	{

return[
	{mobId:1001,mobName:"iPhone",mobPrice:76661.10},
	{mobId:1002,mobName:"MicroMax",mobPrice:126661.10},
	{mobId:1003,mobName:"Coolpad",mobPrice:7823},
	{mobId:1004,mobName:"HTC",mobPrice:8876},
	{mobId:1005,mobName:"LG",mobPrice:46661}
	];
	
	}
	
}