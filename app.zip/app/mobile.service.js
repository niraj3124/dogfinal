"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var MobileService = (function () {
    function MobileService() {
    }
    MobileService.prototype.getAllMobile = function () {
        return [
            { mobId: 1001, mobName: "iPhone", mobPrice: 76661.10 },
            { mobId: 1002, mobName: "MicroMax", mobPrice: 126661.10 },
            { mobId: 1003, mobName: "Coolpad", mobPrice: 7823 },
            { mobId: 1004, mobName: "HTC", mobPrice: 8876 },
            { mobId: 1005, mobName: "LG", mobPrice: 46661 }
        ];
    };
    return MobileService;
}());
MobileService = __decorate([
    core_1.Injectable()
], MobileService);
exports.MobileService = MobileService;
//# sourceMappingURL=mobile.service.js.map