"use strict";
var Mobile = (function () {
    function Mobile() {
    }
    return Mobile;
}());
exports.Mobile = Mobile;
//# sourceMappingURL=app.mobilecomponent.js.map