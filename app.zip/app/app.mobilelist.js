"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var mobile_service_1 = require("./mobile.service");
var MobileList = (function () {
    function MobileList(mobservice) {
        this.mobservice = mobservice;
    }
    //this OnInit method is automatically invoked
    MobileList.prototype.ngOnInit = function () {
        this.mobiles = this.mobservice.getAllMobile();
    };
    //on click to the mobile id column this method will invoke to sort data by Id
    MobileList.prototype.sortid = function () {
        this.mobiles.sort(function (name1, name2) {
            if (name1.mobId < name2.mobId) {
                return -1;
            }
            else if (name1.mobId > name2.mobId) {
                return 1;
            }
            else {
                return 0;
            }
        });
    };
    //on click to the  mobile name column this method will invoke to sort data by name
    MobileList.prototype.sortname = function () {
        this.mobiles.sort(function (name1, name2) {
            if (name1.mobName < name2.mobName) {
                return -1;
            }
            else if (name1.mobName > name2.mobName) {
                return 1;
            }
            else {
                return 0;
            }
        });
    };
    //on click to the mobile price column this method will invoke to sort data by price
    MobileList.prototype.sortprice = function () {
        this.mobiles.sort(function (name1, name2) {
            if (name1.mobPrice < name2.mobPrice) {
                return -1;
            }
            else if (name1.mobPrice > name2.mobPrice) {
                return 1;
            }
            else {
                return 0;
            }
        });
    };
    //Delete method on click to the delete button this method will invoke
    MobileList.prototype.deleteData = function (obj) {
        var index = this.mobiles.indexOf(obj);
        this.mobiles.splice(index, 1);
        this.msg = "Data Deleted";
    };
    return MobileList;
}());
MobileList = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.mobilecomponent.html',
        providers: [mobile_service_1.MobileService]
    }),
    __metadata("design:paramtypes", [mobile_service_1.MobileService])
], MobileList);
exports.MobileList = MobileList;
//# sourceMappingURL=app.mobilelist.js.map