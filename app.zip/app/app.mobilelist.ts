import { Component, OnInit } from '@angular/core';

import { IMobile } from './mobile';

import { MobileService } from './mobile.service';

@Component({
	selector:'<my-component></my-component>',
	templateUrl:'./app.mobilecomponent.html',
	providers:[MobileService]

})


export class MobileList implements OnInit
{
	mobId:number;
	mobName:string;
	mobPrice:number;
	msg:string;
	
	mobiles:IMobile[];
	constructor(private mobservice:MobileService){ }
	
	
	
	//this OnInit method is automatically invoked
	
	ngOnInit():void
	{
		this.mobiles=this.mobservice.getAllMobile();
	}
	
	
	//on click to the mobile id column this method will invoke to sort data by Id
	
	sortid():void{
		this.mobiles.sort( function(name1, name2) {
	    if ( name1.mobId < name2.mobId ){
	    	return -1;
	    }else if( name1.mobId > name2.mobId ){
	        return 1;
	    }else{
	    	return 0;	
	    }
	});
	}
	
	//on click to the  mobile name column this method will invoke to sort data by name
	
	sortname():void{
		this.mobiles.sort( function(name1, name2) {
	    if ( name1.mobName < name2.mobName ){
	    	return -1;
	    }else if( name1.mobName > name2.mobName ){
	        return 1;
	    }else{
	    	return 0;	
	    }
	});
	}
	
	
	//on click to the mobile price column this method will invoke to sort data by price
	
	sortprice():void{
		this.mobiles.sort( function(name1, name2) {
	    if ( name1.mobPrice < name2.mobPrice ){
	    	return -1;
	    }else if( name1.mobPrice > name2.mobPrice ){
	        return 1;
	    }else{
	    	return 0;	
	    }
	});
	}
	
	
	//Delete method on click to the delete button this method will invoke
	deleteData(obj:IMobile)
	{
		var index=this.mobiles.indexOf(obj);
		this.mobiles.splice(index,1);
		this.msg="Data Deleted";
	}
	

	
} 